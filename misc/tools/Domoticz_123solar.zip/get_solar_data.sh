#!/bin/bash
#
# /usr/local/bin/get_solar_date.sh
#
# API Interface script between 123solar from Jean-Marc Louviaux and Domoticz
#
# script will provide multiple solar inverters with 1 or 2 strings
# see the remarks in the script for adjusting

# 2016-05-18 Roland Breedveld
#
# put this in the crontab on the Domoticz host:
# */5 * * * * /usr/local/bin/get_solar_data.sh -d >/dev/null 2>&1

# call parameters:
# -d : debug
# -t : test mode, this is a dry run, it won't update domoticz
#
# you should change the IDX=<number> rows to your id in Domoticz, 
# find the right idx number in the Devices list in Domoticz
# if you don't have some values, simple set IDX=0
# in this example inverter 1 have 2 strings, while inverter 2 only has 1
# in Domoticz you first need to create Virtual Sensors:
#
# for kWh you should use "Electric Instant+Counter" note that values are stored in Wh, not in kWh
#
# idx     Name                 Type        SubType     Data 
# 154     Solar_Power          General     kWh         12769.776 kWh     
# 155     Solar_Power_invt_1   General     kWh          8549.873 kWh     
# 156     Solar_Power_invt_2   General     kWh          4219.903 kWh     
# 114     Solar_invt_2_Eff     General     Percentage         81.50%     
# 97      Solar_invt_2_W       Usage       Electric       100.5 Watt     
# 103     Solar_invt_2_V       General     Voltage         170.000 V     
# 106     Solar_invt_2_A       General     Current           0.600 A     
# 110     Solar_invt_2_Grid_V  General     Voltage         231.400 V     
# 112     Solar_invt_2_Grid_A  General     Current           0.400 A     
# 109     Solar_invt_1_Grid_V  General     Voltage         232.500 V     
# 111     Solar_invt_1_Grid_A  General     Current           0.600 A     
# 113     Solar_invt_1_Eff     General     Percentage         93.10%     
# 95      Solar_invt_1-1_W     Usage       Electric        72.2 Watt     
# 96      Solar_invt_1-2_W     Usage       Electric        76.4 Watt     
# 101     Solar_invt_1-1_V     General     Voltage         121.900 V     
# 102     Solar_invt_1-2_V     General     Voltage         127.700 V     
# 104     Solar_invt_1-1_A     General     Current           0.600 A     
# 105     Solar_invt_1-2_A     General     Current           0.600 A
# 153     Power_Consumption    RFXMeter    counter     16257.239 kWh
#
# Solar_invt_1-2 means 2nd string of the 1st inverter
# Power Consumption is only possible if you use a smart-meter with P1 interface, see in the scripa
# If you only have 1 inverter, you can unvcomment all lines with W_TOT, WH_TOT and INVT_2 in it
# If you have 3 or more invertes add everywhere INVT_3 stuff etc

DEBUG_FILE="/home/pi/log/get_solar_debug.log"
SOLAR_HOST_URL="http://localhost/programs/programlive.php"

WH_TOT=0
W_TOT=0
W_INVT_1=0
W_INVT_2=0
WH_INVT_1=0
WH_INVT_2=0
PRINT_WH_TOT=0
export DEBUG="${1}"

function update_domoticz ()
{
  IDX=${1}
  shift
  DAT=${*}
  if [ ! -z "${DAT}" ]
  then
    if [ "${DEBUG}" == "-t" ]
    then
      echo "Update: IDX:${IDX} DAT:${DAT}" 
    else
      if [ "${DEBUG}" == "-d" ]
      then
        (
          printf "$(date '+%y-%m-%d %H:%M') Update: IDX:${IDX} DAT:${DAT} : " 
          if curl -X GET "http://localhost:8080/json.htm?type=command&param=udevice&idx=${IDX}&nvalue=0&svalue=${DAT}" 2>&1|grep "\"OK\"" >/dev/null
          then
            echo "OK"
          else
            echo "ERROR"
          fi
        ) >> ${DEBUG_FILE}
      else
        curl -X GET "http://localhost:8080/json.htm?type=command&param=udevice&idx=${IDX}&nvalue=0&svalue=${DAT}" >/dev/null 2>&1
     fi
    fi
  else
    if [ "${DEBUG}" == "-d" ]
    then
      echo "NOT Updated: IDX:${IDX} DAT:${DAT}" 
    fi
  fi
}

# put here your inverters like "1 2" or just "1" for 1 inverter
for INVT in 1 2
do
  while read LINE
  do
    VAR=$(echo ${LINE}|awk -F: '{print $1}')
    DAT=$(echo ${LINE}|awk -F: '{print $2}')
    if [ "${DEBUG}" == "-t" ]
    then
      echo "${VAR} : ${DAT} "
    fi
    case ${VAR} in
      KWHT)
        # no IDX is used here, it will be summed to the total of the inverter
        if [ "${DAT}" > "0" -a ! -z "${DAT}" ]
        then
          if [ "${INVT}" == "1" ]
          then
            WH_INVT_1=$(echo ${DAT}|awk '{printf("%.0f",$1 * 1000)}')
            IDX=0
          else
            WH_INVT_2=$(echo ${DAT}|awk '{printf("%.0f",$1 * 1000)}')
            IDX=0
          fi
          DAT=$(echo ${DAT}|awk '{printf("%.0f",1000 * $1)}')
          WH_TOT=$(echo ${WH_TOT} ${DAT}|awk '{printf("%.0f",$1+$2)}')
          PRINT_WH_TOT=$(( ${PRINT_WH_TOT} + 1 ))
        else
          IDX=0
          PRINT_WH_TOT=0
        fi
        ;;
      I1P)
        if [ "${INVT}" == "1" ]
        then
          IDX=95
        else
          IDX=97
        fi
        ;;
      I2P)
        if [ "${INVT}" == "1" ]
        then
          IDX=96
        else
          IDX=0
        fi
        ;;
      I1V)
        if [ "${INVT}" == "1" ]
        then
          IDX=101
        else
          IDX=103
        fi
        ;;
      I2V)
        if [ "${INVT}" == "1" ]
        then
          IDX=102
        else
          IDX=0
        fi
        ;;
      I1A)
        if [ "${INVT}" == "1" ]
        then
          IDX=104
        else
          IDX=106
        fi
        ;;
      I2A)
        if [ "${INVT}" == "1" ]
        then
          IDX=105
        else
          IDX=0
        fi
        ;;
      G1P)
        if [ "${INVT}" == "1" ]
        then
          IDX=0
          W_INVT_1=$(echo ${DAT}|awk '{print int($1)}')
        else
          IDX=0
          W_INVT_2=$(echo ${DAT}|awk '{print int($1)}')
        fi
        W_TOT=$(echo ${W_TOT} ${DAT}|awk '{print $1+$2}')
        ;;
      G1V)
        if [ "${INVT}" == "1" ]
        then
          IDX=109
        else
          IDX=110
        fi
        ;;
      G1A)
        if [ "${INVT}" == "1" ]
        then
          IDX=111
        else
          IDX=112
        fi
        ;;
      FRQ)
        if [ "${INVT}" == "1" ]
        then
          IDX=0
        else
          IDX=0
        fi
        ;;
      EFF)
        if [ "${INVT}" == "1" ]
        then
          IDX=113
        else
          IDX=114
        fi
        ;;
      *)
        IDX=0
        ;;
    esac  
    if [ "${IDX}" -gt "0" ]
    then
      update_domoticz ${IDX} ${DAT}
    fi
  done < <(wget -O - ${SOLAR_HOST_URL}?invtnum=${INVT} 2>/dev/null| sed 's/\"//g;s/,/\n/g')
done

if [ "${DEBUG}" == "-t" ]
then
  echo "WH_TOT:${WH_TOT}"
  echo "W_TOT  :${W_TOT}"
fi

# In case of down situation for 1 or more solar systems, get the last stored value from Domoticz
if [ "${PRINT_WH_TOT}" != "2" -o "${WH_TOT}" == "0" ]
then
  # get the latest date in case of connection problems to 1 of the inverters, it might be down, don't forget to chage the right IDX numbers
  WH_INVT_1=$(curl -X GET "http://localhost:8080/json.htm?type=devices&rid=155" 2>/dev/null|grep Data\" |sed 's/ kWh//' | awk -F\" '{printf("%.0f", $4 * 1000 )}')
  WH_INVT_2=$(curl -X GET "http://localhost:8080/json.htm?type=devices&rid=156" 2>/dev/null|grep Data\" |sed 's/ kWh//' | awk -F\" '{printf("%.0f", $4 * 1000 )}')
  WH_TOT=$(echo ${WH_INVT_1} ${WH_INVT_2}|awk '{printf("%.0f", $1 + $2)}')
  if [ "${DEBUG}" == "-t" ]
  then
    echo "WH_INVT_1:${WH_INVT_1}"
    echo "WH_INVT_2:${WH_INVT_2}"
    echo "WH_TOT NEW:${WH_TOT}"
  fi
fi

# this is to calculate usage, only possible if you have a smart meter with P1 interface
P1_IDX=115
P1_WH=$(curl -X GET "http://localhost:8080/json.htm?type=devices&rid=${P1_IDX}" 2>/dev/null| grep Data|sed 's/ //g;s/\"//g;s/[:,]/;/g'|awk -F\; '{print ($2 + $3 - $4 - $5)}')

IDX=153
DAT=$(echo ${WH_TOT} ${P1_WH}|awk '{printf("%.0f",$1 + $2) }')
update_domoticz ${IDX} ${DAT}

IDX=154
DAT="${W_TOT};${WH_TOT}"
update_domoticz ${IDX} ${DAT}

IDX=155
DAT="${W_INVT_1};${WH_INVT_1}"
update_domoticz ${IDX} ${DAT}

IDX=156
DAT="${W_INVT_2};${WH_INVT_2}"
update_domoticz ${IDX} ${DAT}
