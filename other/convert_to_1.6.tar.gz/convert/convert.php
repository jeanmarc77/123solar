<?php
#!/usr/bin/php
if (isset($_SERVER['REMOTE_ADDR'])) {
    die('Browser access not permitted. It must be launched in a terminal: php convert.php');
}
set_time_limit(99999999);

if (shell_exec('ls /var/run/123solar.pid > /dev/null 2>&1')) {
    die("Stop 123solar first: 123solar stop\n");
} else {
    echo "Hello,\n
This script is converting your daily detailled csv files (1.5.x) to 1.6.x compatible.\n";
}

define('checkaccess', TRUE);
include("config/config_main.php");

for ($invtnum = 1; $invtnum <= $NUMINV; $invtnum++) {
    echo "\nProcessing inverter $invtnum\n";
    $DATADIR = "data/invt$invtnum";
    $dir     = $DATADIR . '/csv/';
    
    $cmd    = 'ls -r ' . $dir . ' | grep .csv';
    $output = shell_exec($cmd);
    $output = explode("\n", $output);
    $xfiles = count($output);
    
    for ($i = 0; $i < $xfiles - 1; $i++) {
        
        $oldcsv = file($dir . $output[$i]);
        $array  = preg_split("/,/", $oldcsv[0]);
        $cnt    = count($array);
        
        if ($cnt == 15) {
            $cmd        = 'mv ' . $dir . $output[$i] . ' ' . $dir . $output[$i] . '.tmp'; // temp
            $exec       = shell_exec($cmd);
            $oldcsv     = file($dir . $output[$i] . '.tmp');
            $contalines = count($oldcsv);
            $myFile     = $dir . $output[$i];
            
            $fh = fopen($myFile, 'w+') or die("can't open $myFile file");
            $header = "Time,I1V,I1A,I1P,I2V,I2A,I2P,I3V,I3A,I3P,I4V,I4A,I4P,G1V,G1A,G1P,G2V,G2A,G2P,G3V,G3A,G3P,FRQ,EFF,INVT,BOOT,SR,KWHT\r\n";
            fwrite($fh, $header);
            
            for ($line_num = 1; $line_num < $contalines; $line_num++) {
                $array      = preg_split("/,/", $oldcsv[$line_num]);
                $Time       = $array[0];
                $I1V        = $array[1];
                $I1A        = $array[2];
                $I1P        = $array[3];
                $I2V        = $array[4];
                $I2A        = $array[5];
                $I2P        = $array[6];
                $I3V        = null;
                $I3A        = null;
                $I3P        = null;
                $I4V        = null;
                $I4A        = null;
                $I4P        = null;
                $G1V        = $array[7];
                $G1A        = $array[8];
                $G1P        = $array[9];
                $G2V        = null;
                $G2A        = null;
                $G2P        = null;
                $G3V        = null;
                $G3A        = null;
                $G3P        = null;
                $FRQ        = $array[10];
                $EFF        = $array[11];
                $INVT       = $array[12];
                $BOOT       = $array[13];
                $SSR        = null;
                $KWHT       = $array[14];
                $stringData = "$Time,$I1V,$I1A,$I1P,$I2V,$I2A,$I2P,$I3V,$I3A,$I3P,$I4V,$I4A,$I4P,$G1V,$G1A,$G1P,$G2V,$G2A,$G2P,$G3V,$G3A,$G3P,$FRQ,$EFF,$INVT,$BOOT,$SSR,$KWHT";
                fwrite($fh, $stringData);
            }
            $cmd  = 'rm ' . $dir . $output[$i] . '.tmp';
            $exec = shell_exec($cmd);
            fclose($fh);
            echo ".";
        } else {
            echo "\nSkipping $output[$i] invt $invtnum";
        }
    }
} //multi    
// $exec = shell_exec('rm convert.php');
die("\nDone. You may now remove convert.php\nbye\n");
?>
