Script to convert the daily detailled 123Solar csv files 1.5.x to 1.6.x compatible

- Make a backup !!
- Put convert in your 123solar webserver repertory
- Stop 123solar
- launch in a terminal : php convert.php
- Good luck ;)
